# Panel: desalineación en la IA de frontera

La web tiene dos archivos:

- `index.html` es la página. No hace falta tocarla.
- `incidentes.csv` es el inventario: una fila por caso. Es lo único que se edita.

## Publicar

**GitHub Pages.** Crea un repositorio, sube los dos archivos y ve a *Settings → Pages*. En *Branch* elige `main` y la carpeta `/ (root)` y guarda. En un par de minutos la web aparece en la dirección que muestra esa misma pantalla.

**Netlify.** Conecta ese mismo repositorio desde *Add new site → Import an existing project*, sin configuración adicional. También puedes arrastrar la carpeta con los dos archivos a Netlify Drop.

Con el repositorio conectado, cada cambio que guardes en `incidentes.csv` se publica solo.

## Añadir o corregir un caso

1. Abre `incidentes.csv`, en GitHub (icono del lápiz) o en Excel.
2. Añade una fila nueva o corrige la que quieras.
3. Si usas Excel, guarda como **CSV UTF-8 (delimitado por comas)** para conservar los acentos. La página acepta tanto `;` como `,` como separador.
4. Sube el archivo al repositorio.

Reglas de cada columna:

| Columna | Qué poner |
|---|---|
| `id` | MA-39, MA-40… (único) |
| `fecha` | Texto libre que se muestra, p. ej. `oct. 2026` |
| `orden` | `AAAA-MM`, para ordenar; si hay dos casos en el mismo mes, añade a, b, c (`2026-10a`) |
| `laboratorios` | Separados por barra vertical: `OpenAI\|Anthropic` |
| `categorias` | Códigos C1 a C9 separados por barra vertical: `C1\|C4` |
| `contexto` | `D` (despliegue real), `E` (evaluación) o `E→D` (evaluación con efectos reales) |
| `gravedad` | `Alta`, `Media` o `Baja` |
| `discutido` | `sí` o `no` |
| `url` | Enlace a la fuente principal (opcional) |

El resto de columnas (modelo, título, descripción, evidencia, respuesta, relevancia UE, nota de gravedad) son texto libre.

Las categorías C1 a C9 son la taxonomía cerrada del inventario. Si algún día cambia, se edita al principio del código de `index.html`.

## Comprobar antes de publicar

Si abres `index.html` con doble clic, el navegador no deja leer el CSV y verás un aviso. Es normal: la página funciona una vez publicada.
